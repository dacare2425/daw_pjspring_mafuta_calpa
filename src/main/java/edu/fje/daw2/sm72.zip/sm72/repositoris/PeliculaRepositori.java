package edu.fje.daw2.sm72.repositoris;

import edu.fje.daw2.sm72.models.Pelicula;
import org.springframework.data.repository.CrudRepository;

public interface PeliculaRepositori extends CrudRepository<Pelicula, String> {

}
