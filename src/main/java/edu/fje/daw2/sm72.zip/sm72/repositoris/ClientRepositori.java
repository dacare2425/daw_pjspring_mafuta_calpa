package edu.fje.daw2.sm72.repositoris;

import edu.fje.daw2.sm72.models.Client;
import org.springframework.data.repository.CrudRepository;

public interface ClientRepositori extends CrudRepository<Client, Long> {

}