package edu.fje.daw2.sm72.repositoris;

import edu.fje.daw2.sm72.models.Usuario;
import org.springframework.data.repository.CrudRepository;

public interface UsuarioRepositori extends CrudRepository<Usuario, String> {

}
