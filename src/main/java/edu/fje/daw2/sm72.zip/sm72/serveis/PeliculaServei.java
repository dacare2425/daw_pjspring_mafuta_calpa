package edu.fje.daw2.sm72.serveis;

import edu.fje.daw2.sm72.models.Client;
import edu.fje.daw2.sm72.models.Pelicula;
import edu.fje.daw2.sm72.repositoris.PeliculaRepositori;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Optional;

@Service
public class PeliculaServei {

    @Autowired
    private PeliculaRepositori repositori;

    public ArrayList<Pelicula> obtenerTodas() {
        //return repositori.findAll();
        var it = repositori.findAll();
        var pelis = new ArrayList<Pelicula>();
        it.forEach(pelis::add);
        return pelis;
    }

    public Pelicula obtenirPerId(String id) {
        Optional<Pelicula> optional = repositori.findById(id);
        return optional.orElse(null);
    }

    public void eliminar(String id) {
        repositori.deleteById(id);
    }

    public Pelicula guardar(Pelicula pelicula) {
        return repositori.save(pelicula);
    }

    public void eliminarPorId(String id) {
        repositori.deleteById(id);
    }
}
